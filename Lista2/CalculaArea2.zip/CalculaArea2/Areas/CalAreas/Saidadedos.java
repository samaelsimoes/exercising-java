package CalAreas;
import javax.swing.JOptionPane;


public class Saidadedos {

	public static void saidados(String msg) {

			JOptionPane.showMessageDialog(null, msg, "Resultado",JOptionPane.OK_CANCEL_OPTION);
	}	
}
