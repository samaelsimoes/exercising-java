package CalAreas;

public class IniciaPrograma {

	public static void main(String[] args) {
		
		Comunicadora comu = new Comunicadora();
		comu.executar();
	}
}
